package com.suhaas.capstonestage2.data;


public class LoggedOutException extends Exception {
}
