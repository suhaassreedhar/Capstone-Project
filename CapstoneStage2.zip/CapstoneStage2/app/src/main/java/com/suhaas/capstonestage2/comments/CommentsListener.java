package com.suhaas.capstonestage2.comments;


import com.suhaas.capstonestage2.model.Story;

public interface CommentsListener {

    void onBookmarkClicked(Story story);
}
