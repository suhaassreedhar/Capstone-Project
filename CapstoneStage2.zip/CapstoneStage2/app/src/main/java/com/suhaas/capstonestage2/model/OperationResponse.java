package com.suhaas.capstonestage2.model;


public enum OperationResponse {

    SUCCESS,
    FAILURE,
    LOGIN_EXPIRED

}
