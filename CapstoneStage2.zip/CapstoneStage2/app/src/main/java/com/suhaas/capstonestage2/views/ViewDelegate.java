package com.suhaas.capstonestage2.views;


public interface ViewDelegate {

    boolean isReadyForPull();

}
